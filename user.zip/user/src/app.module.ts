
import { Module } from '@nestjs/common';
import { AuthModule } from './auth/auth.module';
import { SequelizeModule } from '@nestjs/sequelize';
import sequelizeConfig from './sequelize.config';


@Module({
  imports: [AuthModule,
    SequelizeModule.forRoot({
      ...sequelizeConfig.development,
      autoLoadModels: true,
      synchronize: true,
    })],
  controllers: [],
  providers: [],
})
export class AppModule { }
