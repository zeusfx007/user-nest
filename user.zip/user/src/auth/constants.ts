const crypto = require('crypto');

// Generate a random 64-character hexadecimal string (32 bytes)
const secretKey = crypto.randomBytes(32).toString('hex');

// JWT configuration
export const jwtConstants = {
  secret: secretKey,
};
