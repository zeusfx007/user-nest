import { Injectable } from '@nestjs/common';
import { User as UserModel } from 'src/model/usermodel';
import { InjectModel } from '@nestjs/sequelize';
import { UpdateUserDto } from 'src/validator/update-user.dto';
export type User = UserModel;
@Injectable()
export class UsersService {
  private userlist: any = [];
  constructor(@InjectModel(UserModel) private readonly userModel: typeof UserModel) {
    this.loaduserdata();
  }

  /**
  ** This function is used to load all userdata
  */
  async loaduserdata(): Promise<User[]> {
    const data = await this.userModel.findAll();
    this.userlist = data.map((userInstance) => userInstance.dataValues);
    return this.userlist;
  }

  /**
 ** Function checks Wheter user exsist or not 
 ** @param userName
 */
  async findOne(username: string): Promise<User | undefined> {
    this.userlist = this.userlist.length == 0 ? await this.loaduserdata() : this.userlist;
    return this.userlist.find((user) => user.username === username);
  }

  /**
 ** Function find User by Id 
 ** @param Userid
 */
  async findById(id: number): Promise<User | null> {
    return this.userModel.findByPk(id);
  }

  /**
 ** Function Used to Create new User 
 ** @param UserData payload
 */
  async createUser(userData: Partial<UserModel>): Promise<UserModel> {
    const newUser = await this.userModel.create(userData);
    return newUser;
  }

  /**
** Function Used to Remove User 
** @param Userid
*/
  async deleteUser(id: number): Promise<void> {
    const user = await this.userModel.findByPk(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found.`);
    }
    return await user.destroy();
  }

  /**
** Function Used Update user Data 
** @param Userid , Payload to Update
*/
  async updateUser(id: number, updateUserDto: UpdateUserDto): Promise<User | null> {
    const user = await this.userModel.findByPk(id);
    if (!user) {
      return null;
    }
    await user.update(updateUserDto);
    return user;
  }

  /**
** Function Used Update File Name which is Default Null 
** @param Userid , FileName to Update
*/
  async UpdatefileSequence(userid: number, filename: string): Promise<User | null> {
    const user = await this.userModel.findByPk(userid);
    if (!user) {
      return null;
    }
    user.profileimage = filename;
    await user.save();
    return user;
  }

  /**
** Function Used to Return UserImage from Database 
** @param Userid
*/
  async getprofileimage(userid) {
    const user = await this.userModel.findByPk(userid);
    if (!user) {
      return null;
    }
    return user.profileimage
  }
}
