import { Request, Res, Controller, Post, UseGuards, Body, UsePipes, ValidationPipe, HttpCode, HttpStatus, Delete, Query, NotFoundException, Put, Param, Get, UseInterceptors } from '@nestjs/common';
import { AuthGuard } from 'src/auth/auth.guard';
import { UsersService } from './users.service';
import { CreateUserDto } from 'src/validator/create-user.dto';
import { UpdateUserDto } from 'src/validator/update-user.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { multerConfig } from '../../uploads/multer.config';
import { JwtService } from '@nestjs/jwt';
import { Response } from 'express';
import { join } from 'path';
import * as fs from 'fs';



@Controller('user')
export class UserController {
    constructor(private userService: UsersService, private readonly jwtService: JwtService) { }

    @HttpCode(HttpStatus.OK)
    @Post('createuser')
    @UsePipes(new ValidationPipe({ transform: true }))
    createUser(@Body() userData: CreateUserDto) {
        return this.userService.createUser(userData);
    }

    // Get user profile endpoint
    @UseGuards(AuthGuard)
    @Get('profile/:id')
    getUserProfile(@Param('id') id: number) {
        const userProfile = this.userService.findById(id);
        if (!userProfile) {
            throw new NotFoundException(`User with ID ${id} not found.`);
        }
        return userProfile;
    }

    // Delete user profile endpoint
    @UseGuards(AuthGuard)
    @Delete('deleteuser')
    deleteUser(@Query('id') id: number) {
        if (this.userService.deleteUser(id)) {
            throw new NotFoundException(`User with ID ${id} not found.`);
        }
        return { message: `User with ID ${id} has been deleted.` };
    }

    // Update user profile endpoint
    @UseGuards(AuthGuard)
    @Put('updateuser/:id')
    async updateUser(@Param('id') id: number, @Body() updateUserDto: UpdateUserDto) {
        const updatedUser = await this.userService.updateUser(id, updateUserDto);
        if (!updatedUser) {
            throw new NotFoundException(`User with ID ${id} not found.`);
        }
        return updatedUser;
    }

     // Upload profile image endpoint
    @UseGuards(AuthGuard)
    @Post('upload')
    @UseInterceptors(FileInterceptor('file', multerConfig))
    async uploadFile(@Request() req) {
        const authHeader = req.headers['authorization'];
        let token;
        if (authHeader && typeof authHeader === 'string') {
            token = authHeader.split(' ')[1];
        }
        const generatedFilename = req.generatedFilename;
        try {
            const decoded = this.jwtService.verify(token);
            const id = decoded.userid;
            await this.userService.UpdatefileSequence(id, generatedFilename)
        } catch (error) {
            throw new Error('Invalid token');
        }
        return { message: 'File uploaded successfully' };
    }

     // Get  profile image endpoint
    @UseGuards(AuthGuard)
    @Get('profile-image/:id')
    async getProfileImages(@Param('id') id: number, @Res() res: Response): Promise<void> {
        try {
            const profileImageName = await this.userService.getprofileimage(id);
            const imagePath = join(__dirname, '..', '..', 'uploads', profileImageName);

            if (fs.existsSync(imagePath)) {
                res.setHeader('Content-Type', 'image/png');
                const stream = fs.createReadStream(imagePath);
                stream.pipe(res);
            } else {
                res.status(404).json({ error: 'Image not found' });
            }
        } catch (error) {
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

}
