import { Module } from '@nestjs/common';
import { UsersService } from './user/users.service';
import { UserController } from './user/user.controller';
import { SequelizeModule } from '@nestjs/sequelize';
import { User as usermodel } from '../model/usermodel';
@Module({
  imports: [SequelizeModule.forFeature([usermodel])],
  providers: [UsersService],
  exports: [UsersService],
  controllers: [UserController],
})
export class UsersModule { }
