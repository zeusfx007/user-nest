import { diskStorage } from 'multer';
import * as path from 'path';

/**
** Upload file config 
*/
export const multerConfig = {
  storage: diskStorage({
    destination: (req, file, cb) => {
      const absolutePath = path.resolve('./dist/src/uploads');
      cb(null, absolutePath);
    },
    filename: (req, file, cb) => {
      const fileExtension = path.extname(file.originalname);
      const uniqueFilename = `${Date.now()}${fileExtension}`;
      req.generatedFilename = uniqueFilename;
      cb(null, uniqueFilename);
    },
  }),
};
